import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from 'src/login/login.component';
import{HttpClientModule} from '@angular/common/http'
import { HomeComponent } from '../home/home.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeaderComponent } from '../header/header.component';
import { PaidComponent } from './paid/paid.component';
import { UnPaidComponent } from './un-paid/un-paid.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { ChoisePaymentComponent } from './choise-payment/choise-payment.component';
import { ConformPaymentComponent } from './conform-payment/conform-payment.component';
import { FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { NewComponentComponent } from './new-component/new-component.component';
import { InvoiceWalletComponent } from './invoice-wallet/invoice-wallet.component';
import { WalletPaymentComponent } from './wallet-payment/wallet-payment.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { ConformedComponent } from './conformed/conformed.component';
import { BillGenerationComponent } from './bill-generation/bill-generation.component'; // Import MatCardModule



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    HeaderComponent,
    PaidComponent,
    UnPaidComponent,
    InvoiceComponent,
    ChoisePaymentComponent,
    ConformPaymentComponent,
    NewComponentComponent,
    InvoiceWalletComponent,
    WalletPaymentComponent,
    ConformedComponent,
    BillGenerationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    FormsModule, // Import FormsModule
    ReactiveFormsModule, // Import ReactiveFormsModule
    MatFormFieldModule,
    MatInputModule,
    MatCardModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
