import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-component',
  templateUrl: './new-component.component.html',
  styleUrls: ['./new-component.component.css']
})
export class NewComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  validateExpiryDate(month: string, year: string): boolean {
const currentYear = new Date().getFullYear();
const currentMonth = new Date().getMonth() + 1; 
const expiryYear = parseInt(year, 10);
const expiryMonth = parseInt(month, 10);

if (expiryYear < currentYear || (expiryYear === currentYear && expiryMonth < currentMonth)) {
  return false; 
}

return true;
}
isValidCardNumber(cardNumber: string): boolean {
  return /^\d{16}$/.test(cardNumber);
}
isValidCVV(cvv: string): boolean {
  return /^\d{3}$/.test(cvv);
  }


// if ((this.isValidCardNumber(this.acc) && this.validateExpiryDate(this.month, this.year) && this.isValidCVV(this.cvv))) {
//   const paymentSuccessful = true;

//   if (paymentSuccessful) {
//     this.successMessage = 'Payment successful.';
    // this.pay.payamount(this.id).subscribe(
    //   (response)=>{
    //     console.log(response)
    //   }
    // )
//     this.router.navigate(["./invoice"])

//   } else {
//     this.errorMessage = 'Payment failed. Please try again.';
//   }
// } else {
//   this.errorMessage = 'Please enter valid card details.';
// }



// }



























}
