export class PaymentModes {
             paymentModeId!:number
	paymentModeName!:string
	 discountPercentage!:number;
     rate:number=41.5;
	dateDiscount!:number;
}
