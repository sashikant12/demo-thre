import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';
import { CustomerBill } from '../customer-bill';

@Component({
  selector: 'app-bill-generation',
  templateUrl: './bill-generation.component.html',
  styleUrls: ['./bill-generation.component.css']
})
export class BillGenerationComponent implements OnInit {
  userId:any=sessionStorage.getItem("customerId");
  selectedBillId:any=sessionStorage.getItem("billId");
  Bills!:CustomerBill[];
  constructor(private customerService : CustomerService,private router:Router) { }

  // ngOnInit(){
  //   this.getBill(this.userId,this.selectedBillId)
  //     }
    
  //     getBill(userId:number,selectedBillId:number){
  //       this.customerService.getBillOfCustomerWithTid(this.userId,this.selectedBillId).subscribe(
  //         (response)=>{
  //           this.paidBills = response;
  //         },
  //         (error) => {
  //           console.error("Error fetching transaction details:", error);
  //         }
  //       );
  //     }

  ngOnInit(): void {
    this.InvoiceComponent(this.userId,this.selectedBillId);
    // this.InvoiceComponents(this.userId,this.selectedBillId,this.pay);
  }

  InvoiceComponent(userId:any,selectedBillId:any) {
    this.customerService.getBillOfCustomerWithTid(this.userId,this.selectedBillId).subscribe((response) => {
      console.log(response); 
      this.Bills=response; 

    });
  }
  gotoSuccessfulPay(){
        this.router.navigate(['./Home/:userId']);
      }
      
}















// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute, Router } from '@angular/router';
// import { CustomerServiceService } from '../customer-service.service';

// @Component({
//   selector: 'app-paymentportal',
//   templateUrl: './paymentportal.component.html',
//   styleUrls: ['./paymentportal.component.css']
// })
// export class PaymentportalComponent implements OnInit {
//   transactionId: any;
//   customerid: any;
//   transaction: any;
//   paymentsuccess=false;
//   result:any;
//   paymentId!: number;
//   selectedPaymentMethod : string='';

//   constructor(private customerHttp: CustomerServiceService,private route: Router) { }

//  
  
//   gotoSuccessfulPay(){
//     this.route.navigate(['/successfully-paid']);
//   }
// }