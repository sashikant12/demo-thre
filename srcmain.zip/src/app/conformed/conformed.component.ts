import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-conformed',
  templateUrl: './conformed.component.html',
  styleUrls: ['./conformed.component.css']
})
export class ConformedComponent implements OnInit {

  userId:any=sessionStorage.getItem("customerId");
  selectedBillId:any=sessionStorage.getItem("billId");
  paymnetMethod:any=sessionStorage.getItem("paymentModeId");

  constructor(private customerService : CustomerService,private router:Router) { }

  goToHome(){
    this.router.navigate(["./Home/:userId"])
  }
  ngOnInit(): void {
    this.ConformPayment(this.userId,this.selectedBillId);
  }

   // ConformPayment
   ConformPayment(userId:any,SelectedBill:any) {
    this.customerService.ConformPayment(this.userId,this.selectedBillId).subscribe((response:any) => {
      console.log(response); 
      
    });
  }
}
