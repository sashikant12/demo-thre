import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConformedComponent } from './conformed.component';

describe('ConformedComponent', () => {
  let component: ConformedComponent;
  let fixture: ComponentFixture<ConformedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConformedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConformedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
