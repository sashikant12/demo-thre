import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-wallet-payment',
  templateUrl: './wallet-payment.component.html',
  styleUrls: ['./wallet-payment.component.css']
})
export class WalletPaymentComponent implements OnInit {

  id!:number;
  walletId: string="";
  walletName: string="";
  errorMessage!: string;
  successMessage!: string;
  userId:any=sessionStorage.getItem("customerId");
  selectedBillId:any=sessionStorage.getItem("billId");

  constructor(private router:Router,private customerService : CustomerService) { }
  
  ngOnInit(): void {
    // this.ConformPayment(this.userId,this.selectedBillId);
  }


  // ConformPayment
//   ConformPayment(userId:any,SelectedBill:any) {
//     this.customerService.ConformPayment(this.userId,this.selectedBillId).subscribe((response:any) => {
//       console.log(response); 
      
//     });
// }

  wallet(){
    if (this.isValidWalletId(this.walletId) && this.isValidWalletName(this.walletName)) {
      const paymentSuccessful = true;
      if (paymentSuccessful) {
        this.successMessage = 'Payment successful!';
        this.router.navigate(["./Passed"]) 
      } else {
        this.errorMessage = 'Payment failed. Please try again.';
      }
    } else {
      this.errorMessage = 'Please enter valid wallet details.';
    }
   
  }
  isValidWalletId(walletId: string): boolean {
    return /^\d{10}$/.test(walletId);
  }

  isValidWalletName(walletName: string): boolean {
    return /^[A-Za-z\s]*$/.test(walletName);
  }
}
