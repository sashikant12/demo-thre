export class Customer {
customerId!:number;
	 name!:string
	 phoneNumber!:string;
 email!:string;
	 address!:string;
}