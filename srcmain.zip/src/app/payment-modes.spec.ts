import { PaymentModes } from './payment-modes';

describe('PaymentModes', () => {
  it('should create an instance', () => {
    expect(new PaymentModes()).toBeTruthy();
  });
});
