import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoiceWalletComponent } from './invoice-wallet.component';

describe('InvoiceWalletComponent', () => {
  let component: InvoiceWalletComponent;
  let fixture: ComponentFixture<InvoiceWalletComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InvoiceWalletComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoiceWalletComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
