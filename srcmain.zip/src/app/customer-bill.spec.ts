import { CustomerBill } from './customer-bill';

describe('CustomerBill', () => {
  it('should create an instance', () => {
    expect(new CustomerBill()).toBeTruthy();
  });
});
