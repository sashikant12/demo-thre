import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-conform-payment',
  templateUrl: './conform-payment.component.html',
  styleUrls: ['./conform-payment.component.css']
})
export class ConformPaymentComponent implements OnInit {
  userId:any=sessionStorage.getItem("customerId");
  selectedBillId:any=sessionStorage.getItem("billId");
  paymnetMethod:any=sessionStorage.getItem("paymentModeId");
  paymentForm!: FormGroup;
  form!: FormGroup;
  constructor(private customerService : CustomerService,private router:Router,private formBuilder: FormBuilder,private fb: FormBuilder) { 
    
  }
  onSubmit(){
    this.router.navigate(["./Passed"])
  }

  ngOnInit(): void {
    // this.ConformPayment(this.userId,this.selectedBillId);
    this.paymentForm = this.formBuilder.group({
      name: ['', Validators.required],
      cardNumber: ['', [Validators.required, Validators.pattern(/^\d{4} \d{4} \d{6}$/)]],
      expiry: ['', [Validators.required, this.isExpiryGreater]],
      cvv: ['', [Validators.required, Validators.pattern(/^\d{3}$/)]],
    });
  }

   isExpiryGreater(control: AbstractControl): { [key: string]: boolean } | null {
    const inputValue = control.value;
    if (!/^(0[1-9]|1[0-2])\/(20\d{2}|[2-9]\d{3})$/.test(inputValue)) {
      // Invalid format, let other validators handle it
      return null;
    }
  
    // Split the expiry date into month and year components
    const [month, year] = inputValue.split('/').map(Number);
  
    // Compare the year and month to "08/2023" (assuming "08/2023" is the reference date)
    if (year > 2023 || (year === 2023 && month > 8)) {
      // Expiry date is greater than "08/2023"
      return null;
    } else {
      // Expiry date is not greater than "08/2023"
      return { 'expiryNotGreater': true };
    }
  }
}
  





































